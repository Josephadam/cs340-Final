from pymongo import MongoClient
from bson.objectid import ObjectId
from pymongo.errors import PyMongoError

class AnimalShelter(object):
    """CRUD operations for Animal collection in MongoDB"""

    def __init__(self, user="aacuser", password="SNHU1234", host="nv-desktop-services.apporto.com", port=33544, db_name="AAC", collection_name="animals"):
        # Initialize MongoDB connection
        uri = f"mongodb://{user}:{password}@{host}:{port}/?authSource=admin"
        self.client = MongoClient(uri)
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]

    def create(self, data):
        if data is not None:
            result = self.collection.insert_one(data)
            return result.inserted_id
        else:
            raise Exception("Nothing to save, because data parameter is empty")

    def read(self, data):
        if data is not None:
            results = self.collection.find(data)
        else:
            raise Exception("Nothing to read, because data parameter is empty")
        return list(results)

    def update(self, query, update_values):
        if not query or not isinstance(query, dict):
            raise Exception("Query parameter is empty or invalid")
        if not update_values or not isinstance(update_values, dict):
            raise Exception("update_values parameter is empty or invalid")
        result = self.collection.update_many(query, {'$set': update_values})
        return result.modified_count

    def delete(self, query):
        if not query or not isinstance(query, dict):
            raise Exception("Query parameter is empty or invalid")
        result = self.collection.delete_many(query)
        return result.deleted_count


